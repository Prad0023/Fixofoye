#!/bin/bash

# Create the main directory

cd Rep-fast

# Create the app structure
mkdir -p Rep-fast/app/\(auth\)
mkdir -p Rep-fast/app/\(tabs\)
mkdir -p Rep-fast/app/repair/device-selection
mkdir -p Rep-fast/app/repair/service-booking
mkdir -p Rep-fast/app/orders/cancel
mkdir -p Rep-fast/app/support
mkdir -p Rep-fast/assets/fonts
mkdir -p Rep-fast/assets/images
mkdir -p Rep-fast/assets/animations
mkdir -p Rep-fast/components/auth
mkdir -p Rep-fast/components/common
mkdir -p Rep-fast/components/home
mkdir -p Rep-fast/components/orders
mkdir -p Rep-fast/components/repair
mkdir -p Rep-fast/components/support
mkdir -p Rep-fast/hooks
mkdir -p Rep-fast/services
mkdir -p Rep-fast/store/slices
mkdir -p Rep-fast/utils
mkdir -p Rep-fast/theme
mkdir -p Rep-fast/navigation
mkdir -p Rep-fast/types
mkdir -p Rep-fast/config

# Create auth files
touch Rep-fast/app/\(auth\)/onboarding.tsx
touch Rep-fast/app/\(auth\)/sign-in.tsx
touch Rep-fast/app/\(auth\)/sign-up.tsx
touch Rep-fast/app/\(auth\)/complete-profile.tsx
touch Rep-fast/app/\(auth\)/_layout.tsx

# Create tabs files
touch Rep-fast/app/\(tabs\)/_layout.tsx
touch Rep-fast/app/\(tabs\)/index.tsx
touch Rep-fast/app/\(tabs\)/orders.tsx
touch Rep-fast/app/\(tabs\)/profile.tsx

# Create repair files
touch Rep-fast/app/repair/current-device.tsx
touch Rep-fast/app/repair/device-selection/brand.tsx
touch Rep-fast/app/repair/device-selection/model.tsx
touch Rep-fast/app/repair/device-selection/color.tsx
touch Rep-fast/app/repair/device-selection/condition.tsx
touch Rep-fast/app/repair/issues-analysis.tsx
touch Rep-fast/app/repair/cost-estimator.tsx
touch Rep-fast/app/repair/service-booking/pickup-dropoff.tsx
touch Rep-fast/app/repair/service-booking/address.tsx
touch Rep-fast/app/repair/service-booking/stores.tsx
touch Rep-fast/app/repair/service-booking/schedule.tsx
touch Rep-fast/app/repair/service-booking/security-payment.tsx
touch Rep-fast/app/repair/confirmation.tsx

# Create orders files
touch Rep-fast/app/orders/\[id\].tsx
touch Rep-fast/app/orders/cancel/confirm.tsx
touch Rep-fast/app/orders/cancel/reasons.tsx
touch Rep-fast/app/orders/cancel/success.tsx

# Create support files
touch Rep-fast/app/support/index.tsx
touch Rep-fast/app/support/faq.tsx
touch Rep-fast/app/support/contact.tsx
touch Rep-fast/app/support/chat.tsx

# Create root app files
touch Rep-fast/app/+not-found.tsx
touch Rep-fast/app/_layout.tsx

# Create component files
touch Rep-fast/components/common/Button.tsx
touch Rep-fast/components/common/Card.tsx
touch Rep-fast/components/common/TextInput.tsx
touch Rep-fast/components/home/BrandStoryCards.tsx
touch Rep-fast/components/home/DeviceCard.tsx
touch Rep-fast/components/home/PromotionCarousel.tsx
touch Rep-fast/components/orders/OrderCard.tsx
touch Rep-fast/components/orders/StatusTimeline.tsx
touch Rep-fast/components/repair/DeviceSelector.tsx
touch Rep-fast/components/repair/IssueAnalyzer.tsx

# Create hooks
touch Rep-fast/hooks/useAuth.ts
touch Rep-fast/hooks/useDevice.ts
touch Rep-fast/hooks/useOrders.ts
touch Rep-fast/hooks/useAppState.ts

# Create services
touch Rep-fast/services/api.ts
touch Rep-fast/services/authService.ts
touch Rep-fast/services/deviceService.ts
touch Rep-fast/services/orderService.ts
touch Rep-fast/services/repairService.ts

# Create store files
touch Rep-fast/store/slices/authSlice.ts
touch Rep-fast/store/slices/deviceSlice.ts
touch Rep-fast/store/slices/orderSlice.ts
touch Rep-fast/store/index.ts

# Create utils
touch Rep-fast/utils/analytics.ts
touch Rep-fast/utils/formatters.ts
touch Rep-fast/utils/validation.ts
touch Rep-fast/utils/storage.ts

# Create theme files
touch Rep-fast/theme/colors.ts
touch Rep-fast/theme/spacing.ts
touch Rep-fast/theme/typography.ts
touch Rep-fast/theme/index.ts

# Create navigation files
touch Rep-fast/navigation/linking.ts

# Create type definitions
touch Rep-fast/types/api.types.ts
touch Rep-fast/types/navigation.types.ts
touch Rep-fast/types/models.types.ts

# Create config files
touch Rep-fast/config/constants.ts
touch Rep-fast/config/env.ts
touch Rep-fast/config/api-config.ts

# Create root project files
touch Rep-fast/app.json
touch Rep-fast/babel.config.js
touch Rep-fast/tsconfig.json
touch Rep-fast/package.json

echo "Rep-Fast project structure created successfully!"
